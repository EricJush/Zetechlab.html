<?php
session_start();
require_once "config.php";

// Check if admin is logged in
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: admin_login.php");
    exit;
}

// Function to add new booking
if (isset($_POST['add_booking'])) {
    $lecturer_id = mysqli_real_escape_string($conn, $_POST['lecturer_id']);
    $lab_id = mysqli_real_escape_string($conn, $_POST['lab_id']);
    $unit_id = mysqli_real_escape_string($conn, $_POST['unit_id']);
    $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);
    $start_time = mysqli_real_escape_string($conn, $_POST['start_time']);
    $end_time = mysqli_real_escape_string($conn, $_POST['end_time']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $sql = "INSERT INTO bookings (lecturer_id, lab_id, unit_id, booking_date, start_time, end_time, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "iiissss", $lecturer_id, $lab_id, $unit_id, $booking_date, $start_time, $end_time, $status);
        mysqli_stmt_execute($stmt);
    }
}


// Function to register new lecturer
if (isset($_POST['register_lecturer'])) {
    $admission = mysqli_real_escape_string($conn, $_POST['admission_number']);
    $firstname = mysqli_real_escape_string($conn, $_POST['first_name']);
    $lastname = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $department = mysqli_real_escape_string($conn, $_POST['department']);

    $sql = "INSERT INTO lecturers (admission_number, first_name, last_name, email, password, department) 
            VALUES (?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssssss", $admission, $firstname, $lastname, $email, $password, $department);
        mysqli_stmt_execute($stmt);
    }
}

// Function to add new student
if (isset($_POST['add_student'])) {
    $admission_number = mysqli_real_escape_string($conn, $_POST['admission_number']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO students (admission_number, first_name, last_name, email, phone_number, password) 
            VALUES (?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssssss", $admission_number, $first_name, $last_name, $email, $phone_number, $password);
        mysqli_stmt_execute($stmt);
}
}


// Function to add new lab
if (isset($_POST['add_lab'])) {
    $lab_name = mysqli_real_escape_string($conn, $_POST['lab_name']);
    $capacity = mysqli_real_escape_string($conn, $_POST['capacity']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $sql = "INSERT INTO computer_labs (lab_name, capacity, description, status) 
            VALUES (?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "siss", $lab_name, $capacity, $description, $status);
        mysqli_stmt_execute($stmt);
    }
}

// Function to add new unit
if (isset($_POST['add_unit'])) {
    $unit_code = mysqli_real_escape_string($conn, $_POST['unit_code']);
    $unit_name = mysqli_real_escape_string($conn, $_POST['unit_name']);
    $department = mysqli_real_escape_string($conn, $_POST['unit_department']);

    $sql = "INSERT INTO units (unit_code, unit_name, department) 
            VALUES (?, ?, ?)";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "sss", $unit_code, $unit_name, $department);
        mysqli_stmt_execute($stmt);
    }
}

// Fetch all bookings for admin review
$bookings_sql = "SELECT b.*, l.first_name, l.last_name, c.lab_name, u.unit_name 
                 FROM bookings b 
                 JOIN lecturers l ON b.lecturer_id = l.lecturer_id 
                 JOIN computer_labs c ON b.lab_id = c.lab_id 
                 JOIN units u ON b.unit_id = u.unit_id 
                 ORDER BY b.booking_date DESC";
$bookings_result = mysqli_query($conn, $bookings_sql);

// Fetch all labs
$labs_sql = "SELECT * FROM computer_labs";
$labs_result = mysqli_query($conn, $labs_sql);

// Fetch all units
$units_sql = "SELECT * FROM units";
$units_result = mysqli_query($conn, $units_sql);

// Fetch all lecturers
$lecturers_sql = "SELECT * FROM lecturers";
$lecturers_result = mysqli_query($conn, $lecturers_sql);

// Fetch all registered students
$students_sql = "SELECT * FROM students";
$students_result = mysqli_query($conn, $students_sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Zetech Lab Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<style>
    body {
        padding-bottom: 10px;
    }

    @media (max-width: 768px) {
        body {
            padding-bottom: 100px;
        }
    }
</style>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Zetech Lab Booking System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#bookings"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#labs"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#units"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#lecturers"></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#students"></a>
                        </li>
                </ul>
                <a href="logout.php" class="btn btn-light">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Tabs -->
        <ul class="nav nav-tabs" id="adminTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="bookings-tab" data-bs-toggle="tab" href="#bookings">Bookings</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="labs-tab" data-bs-toggle="tab" href="#labs">Labs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="units-tab" data-bs-toggle="tab" href="#units">Units</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="lecturers-tab" data-bs-toggle="tab" href="#lecturers">Lecturers</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="students-tab" data-bs-toggle="tab" href="#students">Students</a>
            </li>
        </ul>

        <div class="tab-content mt-3">

        <!-- Bookings Tab -->
            <div class="tab-pane fade show active" id="bookings">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Booking Requests</h3>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBookingModal">
                        Add New Booking
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Lecturer</th>
                                <th>Lab</th>
                                <th>Unit</th>
                                <th>Date & Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($booking = mysqli_fetch_assoc($bookings_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($booking['first_name'] . ' ' . $booking['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['lab_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['unit_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['booking_date'] . ' ' . $booking['start_time'] . ' - ' . $booking['end_time']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $booking['status'] == 'approved' ? 'success' : ($booking['status'] == 'rejected' ? 'danger' : 'warning'); ?>">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($booking['status'] == 'pending'): ?>
                                            <a href="update_booking.php?id=<?php echo $booking['booking_id']; ?>&action=approve" class="btn btn-sm btn-success me-2">Approve</a>
                                            <a href="update_booking.php?id=<?php echo $booking['booking_id']; ?>&action=reject" class="btn btn-sm btn-danger">Reject</a>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-warning me-2" data-id="<?php echo $booking['booking_id']; ?>" data-type="bookings">Edit</button>
                                        <button class="btn btn-sm btn-danger" data-id="<?php echo $booking['booking_id']; ?>" data-type="bookings">Delete</button>
                                        
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Labs Tab -->
            <div class="tab-pane fade" id="labs">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Computer Labs</h3>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLabModal">
                        Add New Lab
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Lab Name</th>
                                <th>Capacity</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($lab = mysqli_fetch_assoc($labs_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($lab['lab_name']); ?></td>
                                    <td><?php echo htmlspecialchars($lab['capacity']); ?></td>
                                    <td><?php echo htmlspecialchars($lab['description']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $lab['status'] == 'available' ? 'success' : 'danger'; ?>">
                                            <?php echo ucfirst($lab['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-2" data-id="<?php echo $lab['lab_id']; ?>" data-type="lab">Edit</button>
                                        <button class="btn btn-sm btn-danger" data-id="<?php echo $lab['lab_id']; ?>" data-type="lab">Delete</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Units Tab -->
            <div class="tab-pane fade" id="units">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Units</h3>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUnitModal">
                        Add New Unit
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Unit Name</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($unit = mysqli_fetch_assoc($units_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($unit['unit_code']); ?></td>
                                    <td><?php echo htmlspecialchars($unit['unit_name']); ?></td>
                                    <td><?php echo htmlspecialchars($unit['department']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-2" data-id="<?php echo $unit['unit_id']; ?>" data-type="unit">Edit</button>
                                        <button class="btn btn-sm btn-danger" data-id="<?php echo $unit['unit_id']; ?>" data-type="unit">Delete</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Lecturers Tab -->
            <div class="tab-pane fade" id="lecturers">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Lecturers</h3>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLecturerModal">
                        Add New Lecturer
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Staff Number</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($lecturer = mysqli_fetch_assoc($lecturers_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($lecturer['admission_number']); ?></td>
                                    <td><?php echo htmlspecialchars($lecturer['first_name'] . ' ' . $lecturer['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($lecturer['email']); ?></td>
                                    <td><?php echo htmlspecialchars($lecturer['department']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-2" data-id="<?php echo $lecturer['lecturer_id']; ?>" data-type="lecturer">Edit</button>
                                        <button class="btn btn-sm btn-danger" data-id="<?php echo $lecturer['lecturer_id']; ?>" data-type="lecturer">Delete</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Students Tab -->
            <div class="tab-pane fade" id="students">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Registered Students</h3>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                        Add New Student
                    </a>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Adm No.</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone No.</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($student = mysqli_fetch_assoc($students_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    <td><?php echo htmlspecialchars($student['admission_number']); ?></td>
                                    <td><?php echo htmlspecialchars($student['first_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    <td><?php echo htmlspecialchars($student['phone_number']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning me-2" data-id="<?php echo $student['student_id']; ?>" data-type="student">Edit</button>
                                        <button class="btn btn-sm btn-danger" data-id="<?php echo $student['student_id']; ?>" data-type="student">Delete</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Boking Modal -->
    <div class="modal fade" id="addBookingModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Booking</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Select Lecturer</label>
                            <select name="lecturer_id" class="form-control" required>
                                <?php
                                $lecturers_sql = "SELECT lecturer_id, first_name, last_name FROM lecturers";
                                $lecturers_result = mysqli_query($conn, $lecturers_sql);
                                while ($lecturer = mysqli_fetch_assoc($lecturers_result)) {
                                    echo "<option value='" . $lecturer['lecturer_id'] . "'>" . 
                                        $lecturer['first_name'] . " " . $lecturer['last_name'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Select Lab</label>
                            <select name="lab_id" class="form-control" required>
                                <?php
                                $labs_sql = "SELECT lab_id, lab_name FROM computer_labs WHERE status='available'";
                                $labs_result = mysqli_query($conn, $labs_sql);
                                while ($lab = mysqli_fetch_assoc($labs_result)) {
                                    echo "<option value='" . $lab['lab_id'] . "'>" . $lab['lab_name'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Select Unit</label>
                            <select name="unit_id" class="form-control" required>
                                <?php
                                $units_sql = "SELECT unit_id, unit_name FROM units";
                                $units_result = mysqli_query($conn, $units_sql);
                                while ($unit = mysqli_fetch_assoc($units_result)) {
                                    echo "<option value='" . $unit['unit_id'] . "'>" . $unit['unit_name'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="booking_date" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">End Time</label>
                            <input type="time" name="end_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-control" required>
                                <option value="pending">Pending</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </div>
                        <button type="submit" name="add_booking" class="btn btn-primary">Add Booking</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Lab Modal -->
    <div class="modal fade" id="addLabModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Lab</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Lab Name</label>
                            <input type="text" name="lab_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Capacity</label>
                            <input type="number" name="capacity" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-control" required>
                                <option value="available">Available</option>
                                <option value="maintenance">Maintenance</option>
                                <option value="occupied">Occupied</option>
                            </select>
                        </div>
                        <button type="submit" name="add_lab" class="btn btn-primary">Add Lab</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Unit Modal -->
    <div class="modal fade" id="addUnitModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Unit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Unit Code</label>
                            <input type="text" name="unit_code" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Unit Name</label>
                            <input type="text" name="unit_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department</label>
                            <input type="text" name="unit_department" class="form-control" required>
                        </div>
                        <button type="submit" name="add_unit" class="btn btn-primary">Add Unit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Lecturer Modal -->
    <div class="modal fade" id="addLecturerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Lecturer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Staff Number</label>
                            <input type="text" name="admission_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department</label>
                            <input type="text" name="department" class="form-control" required>
                        </div>
                        <button type="submit" name="register_lecturer" class="btn btn-primary">Add Lecturer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Student Modal -->
    <div class="modal fade" id="addStudentModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addStudentForm" method="POST" action="admin_dashboard.php" data-type="student">
                        <div class="mb-3">
                            <label class="form-label">Admission Number</label>
                            <input type="text" name="admission_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="number" name="phone_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" name="add_student" class="btn btn-primary">Add Student</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteConfirmModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this item?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Bookings Modal -->
     <div class="modal fade" id="editBookingModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Booking</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="editBookingForm">
                        <input type="hidden" name="booking_id" id="edit_booking_id">
                        <div class="mb-3">
                            <label class="form-label">Lab Name</label>
                            <input type="text" name="lab_name" id="edit_lab_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="date" id="edit_date" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" id="edit_start_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">End Time</label>
                            <input type="time" name="end_time" id="edit_end_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" id="edit_status" class="form-control" required>
                                <option value="pending">Pending</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </div>
                        <button type="submit" name="update_booking" class="btn btn-primary" data-id="<?php echo $booking['booking_id']; ?>" data-type="booking">Update Boking</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
                        
    <!-- Edit Lab Modal -->
    <div class="modal fade" id="editLabModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Lab</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="editLabForm">
                        <input type="hidden" name="lab_id" id="edit_lab_id">
                        <div class="mb-3">
                            <label class="form-label">Lab Name</label>
                            <input type="text" name="lab_name" id="edit_lab_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Capacity</label>
                            <input type="number" name="capacity" id="edit_capacity" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" id="edit_status" class="form-control" required>
                                <option value="available">Available</option>
                                <option value="maintenance">Maintenance</option>
                                <option value="occupied">Occupied</option>
                            </select>
                        </div>
                        <button type="submit" name="update_lab" class="btn btn-primary" data-id="<?php echo $lab['lab_id']; ?>" data-type="lab">Update Lab</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Unit Modal -->
    <div class="modal fade" id="editUnitModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Unit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="editUnitForm" data-type="unit">
                        <input type="hidden" name="unit_id" id="edit_unit_id">
                        <div class="mb-3">
                            <label class="form-label">Unit Code</label>
                            <input type="text" name="unit_code" id="edit_unit_code" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Unit Name</label>
                            <input type="text" name="unit_name" id="edit_unit_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department</label>
                            <input type="text" name="unit_department" id="edit_unit_department" class="form-control" required>
                        </div>
                        <button type="submit" name="update_unit" class="btn btn-primary" data-id="<?php echo $unit['unit_id']; ?>" data-type="unit">Update Unit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Lecturer Modal -->
    <div class="modal fade" id="editLecturerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Lecturer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="editLecturerForm" data-type="lecturer">
                        <input type="hidden" name="lecturer_id" id="edit_lecturer_id">
                        <div class="mb-3">
                            <label class="form-label">Admission Number</label>
                            <input type="text" name="admission_number" id="edit_admission_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" id="edit_first_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" id="edit_last_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department</label>
                            <input type="text" name="department" id="edit_department" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password (leave blank to keep current)</label>
                            <input type="password" name="password" id="edit_password" class="form-control">
                            <small class="text-muted">Only fill this if you want to change the password</small>
                        </div>
                        <button type="submit" name="update_lecturer" class="btn btn-primary" data-id="<?php echo $lecturer['lecturer_id']; ?>" data-type="lecturer">Update Lecturer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Student Modal -->
    <div class="modal fade" id="editStudentModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="editStudentForm" data-type="student">
                        <input type="hidden" name="student_id" id="edit_student_id">
                        <div class="mb-3">
                            <label class="form-label">Admission Number</label>
                            <input type="text" name="admission_number" id="edit_admission_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" id="edit_first_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" id="edit_last_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="number" name="phone_number" id="edit_phone_number" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password (leave blank to keep current)</label>
                            <input type="password" name="password" id="edit_password" class="form-control">
                            <small class="text-muted">Only fill this if you want to change the password</small>
                        </div>
                        <button type="submit" name="update_student" class="btn btn-primary" data-id="<?php echo $student['student_id']; ?>" data-type="lecturer">Update Student</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap and jQuery Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <!-- Custom JavaScript -->
    <script>
        $(document).ready(function() {
            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            // Handle delete confirmation
            let deleteId = null;
            let deleteType = null;

            $('.btn-danger[data-type]').click(function() {
                deleteId = $(this).data('id');
                deleteType = $(this).data('type');
                $('#deleteConfirmModal').modal('show');
            });

            $('#confirmDelete').click(function() {
                if (deleteId && deleteType) {
                    $.ajax({
                        url: 'delete.php',
                        type: 'GET',
                        data: {
                            type: deleteType,
                            id: deleteId
                        },
                        dataType: 'json', // Specify that we expect JSON response
                        success: function(response) {
                            $('#deleteConfirmModal').modal('hide');
                            if (response.success) {
                                alert(response.message);
                                location.reload();
                            } else {
                                alert(response.message || 'Error deleting item');
                            }
                        },
                        error: function(xhr, status, error) {
                            $('#deleteConfirmModal').modal('hide');
                            console.error('Delete request failed:', error);
                            alert('Error processing delete request');
                        }
                    });
                }
            });

            // Handle edit button clicks
            $('.btn-warning').click(function() {
                const id = $(this).data('id');
                const type = $(this).data('type');

                $.ajax({
                    url: 'get_item.php',
                    type: 'GET',
                    data: {
                        type: type,
                        id: id
                    },
                    success: function(response) {
                        if (response.success) {
                            const data = response.data;
                            console.log('Received data:', data);
                            switch (type) {
                                case 'bookings':
                                    $('#edit_booking_id').val(data.booking_id);
                                    $('#edit_lab_id').val(data.lab_name || data.lab_id);
                                    $('#edit_date').val(data.booking_date);
                                    $('#edit_start_time').val(data.start_time);
                                    $('#edit_end_time').val(data.end_time);
                                    $('#edit_status').val(data.status);
                                    $('#editBookingModal').modal('show');
                                    break;
                                case 'lab':
                                    $('#edit_lab_id').val(data.lab_id);
                                    $('#edit_lab_name').val(data.lab_name || data.lab_id);
                                    $('#edit_capacity').val(data.capacity);
                                    $('#edit_description').val(data.description);
                                    $('#edit_status').val(data.status);
                                    $('#editLabModal').modal('show');
                                    break;
                                case 'unit':
                                    $('#edit_unit_id').val(data.unit_id);
                                    $('#edit_unit_code').val(data.unit_code);
                                    $('#edit_unit_name').val(data.unit_name);
                                    $('#edit_unit_department').val(data.department);
                                    $('#editUnitModal').modal('show');
                                    break;
                                case 'lecturer':
                                    $('#edit_lecturer_id').val(data.lecturer_id);
                                    $('#edit_admission_number').val(data.admission_number);
                                    $('#edit_first_name').val(data.first_name);
                                    $('#edit_last_name').val(data.last_name);
                                    $('#edit_email').val(data.email);
                                    $('#edit_department').val(data.department);
                                    $('#editLecturerModal').modal('show');
                                    break;
                                case 'student':
                                    $('#edit_student_id').val(data.student_id);
                                    $('#edit_admission_number').val(data.admission_number);
                                    $('#edit_first_name').val(data.first_name);
                                    $('#edit_last_name').val(data.last_name);
                                    $('#edit_email').val(data.email);
                                    $('#edit_phone_number').val(data.phone_number);
                                    $('#editStudentModal').modal('show');
                                break;   
                            }
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function() {
                        alert('Error fetching item details');
                    }
                });
            });

            // Handle form submissions for updates
            $('#editBookingForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                submitUpdate('bookings', formData);
            });

            $('#editLabForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                submitUpdate('lab', formData);
            });

            $('#editUnitForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                submitUpdate('unit', formData);
            });

            $('#editLecturerForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                submitUpdate('lecturer', formData);
            });

            $('#editStudentForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize();
                submitUpdate('student', formData);
            });


            function submitUpdate(type, formData) {
                $.ajax({
                    url: 'update_item.php',
                    type: 'POST',
                    data: formData + '&type=' + type,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert(response.message || 'Error updating item');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert('Error updating item: ' + error);
                    }
                });
            }
            
        })
    </script>
</body>

</html>