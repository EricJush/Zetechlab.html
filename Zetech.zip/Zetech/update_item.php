<?php
session_start();
require_once "config.php";

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

// prevent any output before JSON response
ob_clean();
header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['type'])) {
        $response['message'] = 'Type parameter is missing';
        echo json_encode($response);
        exit;
    }

    $type = $_POST['type'];
    
    try {
        switch($type) {
            case 'bookings':
                if (!isset($_POST['booking_id'], $_POST['lab_name'], $_POST['date'], $_POST['start_time'], $_POST['end_time'], $_POST['status'])) {
                    throw new Exception("Missing required booking parameters");
                }
                
                // Add validation here
                $booking_date = $_POST['date'];
                $start_time = $_POST['start_time'];
                $end_time = $_POST['end_time'];
                
                // Check for weekends using Sunday(0) to Saturday(6) format
                $day_of_week = date('w', strtotime($booking_date));
                if ($day_of_week == 0 || $day_of_week == 6) {
                    throw new Exception("Bookings are only allowed during weekdays (Monday-Friday)");
                }
                
                // Convert booking times to minutes for comparison
                $start_minutes = (int)substr($start_time, 0, 2) * 60 + (int)substr($start_time, 3, 2);
                $end_minutes = (int)substr($end_time, 0, 2) * 60 + (int)substr($end_time, 3, 2);
                
                // Define allowed time range (8:00 AM to 5:00 PM)
                $allowed_start = 8 * 60;
                $allowed_end = 17 * 60;
                
                if ($start_minutes < $allowed_start || $end_minutes > $allowed_end) {
                    throw new Exception("Bookings can only be made from 08:00 AM to 05:00 PM");
                }
                
                $booking_id = intval($_POST['booking_id']);
                $lab_name = mysqli_real_escape_string($conn, $_POST['lab_name']);
                $start_time = mysqli_real_escape_string($conn, $_POST['start_time']);
                $end_time = mysqli_real_escape_string($conn, $_POST['end_time']);
                $date = mysqli_real_escape_string($conn, $_POST['date']);
                $status = mysqli_real_escape_string($conn, $_POST['status']);
                
                $sql = "UPDATE bookings 
                        SET lab_id = (SELECT lab_id FROM computer_labs WHERE lab_name = ?),
                            booking_date = ?,
                            start_time = ?,
                            end_time = ?,
                            status = ?
                        WHERE booking_id = ?";
                        
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssssi", $lab_name, $date, $start_time, $end_time, $status, $booking_id);
                } else {
                    throw new Exception("Error preparing booking update statement: " . mysqli_error($conn));
                }
                break;    
                                    
            case 'lab':
                if (!isset($_POST['lab_id'], $_POST['lab_name'], $_POST['capacity'], $_POST['description'], $_POST['status'])) {
                    throw new Exception("Missing required lab parameters");
                }
                
                $id = intval($_POST['lab_id']);
                $lab_name = mysqli_real_escape_string($conn, $_POST['lab_name']);
                $capacity = intval($_POST['capacity']);
                $description = mysqli_real_escape_string($conn, $_POST['description']);
                $status = mysqli_real_escape_string($conn, $_POST['status']);
                
                $sql = "UPDATE computer_labs SET lab_name = ?, capacity = ?, description = ?, status = ? WHERE lab_id = ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sissi", $lab_name, $capacity, $description, $status, $id);
                } else {
                    throw new Exception("Error preparing lab update statement: " . mysqli_error($conn));
                }
                break;
                
            case 'unit':
                if (!isset($_POST['unit_id'], $_POST['unit_code'], $_POST['unit_name'], $_POST['unit_department'])) {
                    throw new Exception("Missing required unit parameters");
                }
                
                $id = intval($_POST['unit_id']);
                $unit_code = mysqli_real_escape_string($conn, $_POST['unit_code']);
                $unit_name = mysqli_real_escape_string($conn, $_POST['unit_name']);
                $department = mysqli_real_escape_string($conn, $_POST['unit_department']);
                
                $sql = "UPDATE units SET unit_code = ?, unit_name = ?, department = ? WHERE unit_id = ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssi", $unit_code, $unit_name, $department, $id);
                } else {
                    throw new Exception("Error preparing unit update statement: " . mysqli_error($conn));
                }
                break;
                
            case 'lecturer':
                if (!isset($_POST['lecturer_id'], $_POST['admission_number'], $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['department'])) {
                    throw new Exception("Missing required lecturer parameters");
                }
                
                $id = intval($_POST['lecturer_id']);
                $admission = mysqli_real_escape_string($conn, $_POST['admission_number']);
                $firstname = mysqli_real_escape_string($conn, $_POST['first_name']);
                $lastname = mysqli_real_escape_string($conn, $_POST['last_name']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $department = mysqli_real_escape_string($conn, $_POST['department']);
                
                $sql = "UPDATE lecturers SET admission_number = ?, first_name = ?, last_name = ?, email = ?, department = ? WHERE lecturer_id = ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssssi", $admission, $firstname, $lastname, $email, $department, $id);
                } else {
                    throw new Exception("Error preparing lecturer update statement: " . mysqli_error($conn));
                }
                break;

            case 'student':
                if (!isset($_POST['student_id'], $_POST['admission_number'], $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['phone_number'])) {
                    $missing = [];
                    if (!isset($_POST['student_id'])) $missing[] = 'student_id';
                    if (!isset($_POST['admission_number'])) $missing[] = 'admission_number';
                    if (!isset($_POST['first_name'])) $missing[] = 'first_name';
                    if (!isset($_POST['last_name'])) $missing[] = 'last_name';
                    if (!isset($_POST['email'])) $missing[] = 'email';
                    if (!isset($_POST['phone_number'])) $missing[] = 'phone_number';
                    
                    throw new Exception("Missing required student parameters: " . implode(', ', $missing));
                }
                
                $id = intval($_POST['student_id']);
                $admission = mysqli_real_escape_string($conn, $_POST['admission_number']);
                $firstname = mysqli_real_escape_string($conn, $_POST['first_name']);
                $lastname = mysqli_real_escape_string($conn, $_POST['last_name']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $phonenumber = mysqli_real_escape_string($conn, $_POST['phone_number']);
                
                $sql = "UPDATE students SET admission_number = ?, first_name = ?, last_name = ?, email = ?, phone_number = ? WHERE student_id = ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "sssssi", $admission, $firstname, $lastname, $email, $phonenumber, $id);
                    if (mysqli_stmt_execute($stmt)) {
                        $response['success'] = true;
                        $response['message'] = "Student updated successfully";
                    } else {
                        throw new Exception("Error executing update: " . mysqli_stmt_error($stmt));
                    }
                } else {
                    throw new Exception("Error preparing statement: " . mysqli_error($conn));
                }
                break;
    default:
                throw new Exception("Invalid item type specified: " . $type);
        }
        
        if (!isset($stmt)) {
            throw new Exception("Statement preparation failed");
        }
        
        if (mysqli_stmt_execute($stmt)) {
            if (mysqli_stmt_affected_rows($stmt) > 0) {
                $response['success'] = true;
                $response['message'] = "Item updated successfully";
            } else {
                $response['message'] = "No changes were made";
            }
        } else {
            throw new Exception("Error executing update: " . mysqli_stmt_error($stmt));
        }
        
        mysqli_stmt_close($stmt);
        
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
exit;
?>