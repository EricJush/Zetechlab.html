<?php
session_start();
require_once "config.php";
require_once "email_notifications.php";

if(!isset($_SESSION["lecturer_loggedin"]) || $_SESSION["lecturer_loggedin"] !== true){
    header("location: login.php");
    exit;
}

if(isset($_GET['id'])){
    $booking_id = $_GET['id'];
    $lecturer_id = $_SESSION["lecturer_id"];
    
    // Verify the booking belongs to the lecturer
    $sql = "UPDATE bookings SET status = 'cancelled' 
            WHERE booking_id = ? AND lecturer_id = ? AND status = 'pending'";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "ii", $booking_id, $lecturer_id);
        
        if(mysqli_stmt_execute($stmt)){
            // Get booking details for email notification
            $booking_sql = "SELECT b.*, l.email as lecturer_email, l.first_name, l.last_name,
                           c.lab_name, u.unit_name 
                           FROM bookings b
                           JOIN lecturers l ON b.lecturer_id = l.lecturer_id
                           JOIN computer_labs c ON b.lab_id = c.lab_id
                           JOIN units u ON b.unit_id = u.unit_id
                           WHERE b.booking_id = ?";
            
            if($stmt2 = mysqli_prepare($conn, $booking_sql)){
                mysqli_stmt_bind_param($stmt2, "i", $booking_id);
                mysqli_stmt_execute($stmt2);
                $result = mysqli_stmt_get_result($stmt2);
                $booking = mysqli_fetch_assoc($result);
                
                // Send email notification
                sendBookingStatusEmail($booking, 'cancelled');
            }
        }
    }
    header("location: lecturer_dashboard.php");
}
?>