<?php
if (!defined('DB_SERVER')) {
    define('DB_SERVER', 'localhost');
}
if (!defined('DB_USERNAME')) {
    define('DB_USERNAME', 'root');
}
if (!defined('DB_PASSWORD')) {
    define('DB_PASSWORD', '');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'zetech_lab');
}

// Establish database connection
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// SMTP Settings
if (!defined('SMTP_HOST')) {
    define('SMTP_HOST', 'smtp.gmail.com');  // Or your SMTP server
}
if (!defined('SMTP_USERNAME')) {
    define('SMTP_USERNAME', 'mariaolotira@gmail.com');
}
if (!defined('SMTP_PASSWORD')) {
    define('SMTP_PASSWORD', 'fskj ntxm gzkl dyzq');
}
if (!defined('SMTP_PORT')) {
    define('SMTP_PORT', 587);
}
?>