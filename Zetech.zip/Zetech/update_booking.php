<?php
session_start();
require_once "config.php";
require_once "email_notifications.php";

if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

if(isset($_GET["id"]) && isset($_GET["action"])) {
    $booking_id = $_GET["id"];
    $action = $_GET["action"];
    
    $status = ($action == "approve") ? "approved" : "rejected";
    
    $sql = "UPDATE bookings SET status = ? WHERE booking_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $status, $booking_id);
        mysqli_stmt_execute($stmt);
    }
}

header("location: admin_dashboard.php");
exit();

if(isset($_GET['id']) && isset($_GET['action'])){
    $booking_id = $_GET['id'];
    $action = $_GET['action'];
    
    if($action == 'approve' || $action == 'reject'){
        // Check if there is a conflict with another approved booking in the same lab
        $conflict_sql = "SELECT COUNT(*) as count 
                         FROM bookings 
                         WHERE lab_id = (SELECT lab_id FROM bookings WHERE booking_id = ?)
                         AND start_time <= (SELECT end_time FROM bookings WHERE booking_id = ?)
                         AND end_time >= (SELECT start_time FROM bookings WHERE booking_id = ?)
                         AND status = 'approved'
                         AND booking_id <> ?";
        
        if($stmt = mysqli_prepare($conn, $conflict_sql)){
            mysqli_stmt_bind_param($stmt, "iiii", $booking_id, $booking_id, $booking_id, $booking_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $conflict_count = mysqli_fetch_assoc($result)['count'];
            
            if($conflict_count > 0){
                // There is a conflict, display an error message
                $error_message = "Cannot approve this booking, as there is another approved booking in the same lab during the same time.";
                header("location: admin_dashboard.php?error=$error_message");
                exit;
            }
        }
        
        // No conflict, proceed with approval/rejection
        $sql = "UPDATE bookings SET status = ? WHERE booking_id = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            $status = ($action == 'approve') ? 'approved' : 'rejected';
            mysqli_stmt_bind_param($stmt, "si", $status, $booking_id);
            
            if(mysqli_stmt_execute($stmt)){
                // Get booking details for email notification
                $booking_sql = "SELECT b.*, l.email as lecturer_email, l.first_name, l.last_name, 
                               c.lab_name, u.unit_name 
                               FROM bookings b
                               JOIN lecturers l ON b.lecturer_id = l.lecturer_id
                               JOIN computer_labs c ON b.lab_id = c.lab_id
                               JOIN units u ON b.unit_id = u.unit_id
                               WHERE b.booking_id = ?";
                
                if($stmt2 = mysqli_prepare($conn, $booking_sql)){
                    mysqli_stmt_bind_param($stmt2, "i", $booking_id);
                    mysqli_stmt_execute($stmt2);
                    $result = mysqli_stmt_get_result($stmt2);
                    $booking = mysqli_fetch_assoc($result);
                    
                    // Send email notification
                    sendBookingStatusEmail($booking, $status);
                    sendStudentNotificationEmail($booking, $status);
                }
            }
            header("location: admin_dashboard.php");
        }
    }
}
?>