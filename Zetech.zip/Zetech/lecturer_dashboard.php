<?php
// lecturer_dashboard.php
session_start();
require_once "config.php";

// Check if lecturer is logged in
if(!isset($_SESSION["lecturer_loggedin"]) || $_SESSION["lecturer_loggedin"] !== true){
    header("location: login.php");
    exit;
}

$lecturer_id = $_SESSION["lecturer_id"];

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $booking_date = $_POST['booking_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    
    // Check for weekends using Sunday(0) to Saturday(6) format
    $day_of_week = date('w', strtotime($booking_date));
    if ($day_of_week == 0 || $day_of_week == 6) {
        $error_message = "Bookings are only allowed during weekdays (Monday-Friday)";
    }
    // Convert booking times to minutes for comparison
    else {
        $start_minutes = (int)substr($start_time, 0, 2) * 60 + (int)substr($start_time, 3, 2);
        $end_minutes = (int)substr($end_time, 0, 2) * 60 + (int)substr($end_time, 3, 2);
        
        // Define allowed time range (8:00 AM to 5:00 PM)
        $allowed_start = 8 * 60; // 8:00 AM in minutes
        $allowed_end = 17 * 60;  // 5:00 PM in minutes
        
        if ($start_minutes < $allowed_start || $end_minutes > $allowed_end) {
            $error_message = "Bookings can only be made from 08:00 AM to 05:00 PM";
        }
    }
    
    // Only proceed with booking if there are no errors
    if (empty($error_message)) {
        $lab_id = mysqli_real_escape_string($conn, $_POST['lab_id']);
        $unit_id = mysqli_real_escape_string($conn, $_POST['unit_id']);
        $purpose = mysqli_real_escape_string($conn, $_POST['purpose']);
        
        // Check for conflicting bookings
        $check_sql = "SELECT * FROM bookings WHERE lab_id = ? AND booking_date = ? AND 
                      ((start_time BETWEEN ? AND ?) OR (end_time BETWEEN ? AND ?))";
        
        if($stmt = mysqli_prepare($conn, $check_sql)){
            mysqli_stmt_bind_param($stmt, "isssss", $lab_id, $booking_date, $start_time, $end_time, $start_time, $end_time);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if(mysqli_num_rows($result) == 0){
                $sql = "INSERT INTO bookings (lecturer_id, lab_id, unit_id, booking_date, start_time, end_time, purpose) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                if($stmt = mysqli_prepare($conn, $sql)){
                    mysqli_stmt_bind_param($stmt, "iiissss", $lecturer_id, $lab_id, $unit_id, $booking_date, $start_time, $end_time, $purpose);
                    mysqli_stmt_execute($stmt);
                }
            }
        }
    }
}


// Fetch available labs
$labs_sql = "SELECT * FROM computer_labs WHERE status = 'available'";
$labs_result = mysqli_query($conn, $labs_sql);

// Fetch units
$units_sql = "SELECT * FROM units";
$units_result = mysqli_query($conn, $units_sql);

// Fetch lecturer's bookings
$bookings_sql = "SELECT b.*, c.lab_name, u.unit_name 
                 FROM bookings b
                 JOIN computer_labs c ON b.lab_id = c.lab_id
                 JOIN units u ON b.unit_id = u.unit_id
                 WHERE b.lecturer_id = ?
                 ORDER BY b.booking_date DESC, b.start_time DESC";

$stmt = mysqli_prepare($conn, $bookings_sql);
mysqli_stmt_bind_param($stmt, "i", $lecturer_id);
mysqli_stmt_execute($stmt);
$bookings_result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecturer Dashboard - Zetech Lab Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    body {
        padding-bottom: 10px;
    }

    @media (max-width: 768px) {
        body {
            padding-bottom: 100px;
        }
    }
</style>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand fw-bold">Zetech Lab Booking System</a>
            <div class="d-flex">
                <span class="navbar-text me-3">Welcome, <?php echo htmlspecialchars($_SESSION["lecturer_name"]); ?></span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-body">
                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
        <!-- Your booking form here -->
        <div class="card mb-4">
            <div class="card-body">
                <h2 class="card-title mb-4">Book a Computer Lab</h2>
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Select Lab</label>
                            <select name="lab_id" required class="form-select">
                                <?php while($lab = mysqli_fetch_assoc($labs_result)): ?>
                                    <option value="<?php echo $lab['lab_id']; ?>">
                                        <?php echo htmlspecialchars($lab['lab_name'] . ' (Capacity: ' . $lab['capacity'] . ')'); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Unit</label>
                            <select name="unit_id" required class="form-select">
                                <?php while($unit = mysqli_fetch_assoc($units_result)): ?>
                                    <option value="<?php echo $unit['unit_id']; ?>">
                                        <?php echo htmlspecialchars($unit['unit_code'] . ' - ' . $unit['unit_name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date</label>
                            <input type="date" name="booking_date" required 
                                   min="<?php echo date('Y-m-d'); ?>"
                                   class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" required class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">End Time</label>
                            <input type="time" name="end_time" required class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Purpose</label>
                            <textarea name="purpose" required class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" name="submit_booking" class="btn btn-primary">
                                Submit Booking Request
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- My Bookings -->
        <div class="card">
            <div class="card-body">
                <h2 class="card-title mb-4">My Bookings</h2>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Lab</th>
                                <th>Unit</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($booking = mysqli_fetch_assoc($bookings_result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($booking['lab_name']); ?></td>
                                <td><?php echo htmlspecialchars($booking['unit_name']); ?></td>
                                <td><?php echo htmlspecialchars($booking['booking_date']); ?></td>
                                <td><?php echo htmlspecialchars($booking['start_time'] . ' - ' . $booking['end_time']); ?></td>
                                <td>
                                    <span class="badge <?php 
                                        echo $booking['status'] == 'approved' ? 'bg-success' : 
                                            ($booking['status'] == 'rejected' ? 'bg-danger' : 
                                            'bg-warning'); ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($booking['status'] == 'pending'): ?>
                                    <a href="cancel_booking.php?id=<?php echo $booking['booking_id']; ?>" 
                                       class="text-danger text-decoration-none"
                                       onclick="return confirm('Are you sure you want to cancel this booking?')">
                                        Cancel
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4">
        <p class="text-muted">© <?php echo date("Y"); ?> Zetech Lab Booking. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add client-side validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const startTime = document.querySelector('input[name="start_time"]').value;
            const endTime = document.querySelector('input[name="end_time"]').value;
            
            if (startTime >= endTime) {
                e.preventDefault();
                alert('End time must be after start time');
            }
        });
    </script>
</body>
</html>