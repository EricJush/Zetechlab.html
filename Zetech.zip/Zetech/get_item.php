<?php
//get_item.php
session_start();
require_once "config.php";

// Check if admin is logged in
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: admin_login.php");
    exit;
}

// Initialize response array
$response = [
    'success' => false,
    'data' => null,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['type']) && isset($_GET['id'])) {
    $type = $_GET['type'];
    $id = intval($_GET['id']);

    try {
        switch ($type) {
        case 'bookings':
            $sql = "SELECT b.*, c.lab_name, l.first_name, l.last_name, u.unit_name 
                    FROM bookings b 
                    LEFT JOIN computer_labs c ON b.lab_id = c.lab_id 
                    LEFT JOIN lecturers l ON b.lecturer_id = l.lecturer_id 
                    LEFT JOIN units u ON b.unit_id = u.unit_id 
                    WHERE b.booking_id = ?";
            
            error_log(print_r($response['data'], true));
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $response['data'] = mysqli_fetch_assoc($result);
            break;
                
            case 'lab':
                $sql = "SELECT * FROM computer_labs WHERE lab_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $response['data'] = mysqli_fetch_assoc($result);
                break;

            case 'unit':
                $sql = "SELECT * FROM units WHERE unit_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $response['data'] = mysqli_fetch_assoc($result);
                break;

            case 'student':
                $sql = "SELECT * FROM students WHERE student_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $response['data'] = mysqli_fetch_assoc($result);
                break;

            case 'lecturer':
                $sql = "SELECT * FROM lecturers WHERE lecturer_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $response['data'] = mysqli_fetch_assoc($result);
                // Remove sensitive data
                if ($response['data']) {
                    unset($response['data']['password']);
                }
                break;

            default:
                throw new Exception("Invalid item type specified");
        }

        if ($response['data']) {
            $response['success'] = true;
        } else {
            throw new Exception("Item not found");
        }
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
