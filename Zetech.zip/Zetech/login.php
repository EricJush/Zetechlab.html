<?php
// lecturer login.php
session_start();
require_once "config.php";

$admission_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admission = trim($_POST["admission"]);
    $password = trim($_POST["password"]);
    
    if (empty($admission_err) && empty($password_err)) {
        $sql = "SELECT lecturer_id, admission_number, password, first_name, last_name 
                FROM lecturers WHERE admission_number = ?";
        
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $admission);
            
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $admission, $hashed_password, $first_name, $last_name);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            session_start();
                            
                            $_SESSION["lecturer_loggedin"] = true;
                            $_SESSION["lecturer_id"] = $id;
                            $_SESSION["lecturer_name"] = $first_name . " " . $last_name;
                            
                            header("location: lecturer_dashboard.php");
                        } else {
                            $password_err = "Invalid password.";
                        }
                    }
                } else {
                    $admission_err = "No account found with that admission number.";
                }
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Zetech Lab Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <!-- Logo -->
                    <img src="https://elearning.zetech.ac.ke/pluginfile.php/1/theme_edutor/logo/1727861548/Portrait%20Logo%20282C%20%281%29.png" alt="Zetech Logo" class="h-10 mr-3">
                    <div class="text-2xl font-bold text-blue-900">
                        Zetech Lab Booking
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="flex items-center space-x-4">
                        <a href="index.php" class="text-gray-700 hover:text-blue-900 px-3 py-2">Home</a>
                        <a href="#" class="text-gray-700 hover:text-blue-900 px-3 py-2" id="book-computer"></a>
                        <a href="#help" class="text-gray-700 hover:text-blue-900 px-3 py-2"></a>
                        <a href="student_login.php" class="bg-blue-900 text-white px-4 py-2 rounded-md">Student Login</a>
                        <a href="login.php" class="bg-blue-900 text-white px-4 py-2 rounded-md">Lecturer Login</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="card mx-auto" style="max-width: 400px;">
            <div class="card-body">
                <h2 class="text-center mb-4">Lecturer Login</h2>
                <form method="POST">
                    <div class="mb-3">
                        <label for="admission" class="form-label">Admission Number</label>
                        <input id="admission" name="admission" type="text" required 
                               class="form-control" placeholder="Admission Number">
                        <div class="text-danger"><?php echo $admission_err; ?></div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input id="password" name="password" type="password" required 
                               class="form-control" placeholder="Password">
                        <div class="text-danger"><?php echo $password_err; ?></div>
                    </div>
                    <button type="submit" 
                            class="btn btn-primary w-100">
                        Sign in
                    </button>
                </form>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4">
        <p class="text-muted">© <?php echo date("Y"); ?> Zetech Lab Booking. All rights reserved.</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>