<?php
session_start();
require_once "config.php";

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if admin is logged in
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: admin_login.php");
    exit;
}

// Initialize response array
$response = [
    'success' => false,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['type']) && isset($_GET['id'])) {
    $type = $_GET['type'];
    $id = intval($_GET['id']);

    // Begin transaction
    mysqli_begin_transaction($conn);

    try {
        switch ($type) {
            case 'bookings':
                // Check if booking is approved
                $check_sql = "SELECT status, booking_date, end_time FROM bookings WHERE booking_id = ?";
                $check_stmt = mysqli_prepare($conn, $check_sql);
                mysqli_stmt_bind_param($check_stmt, "i", $id);
                mysqli_stmt_execute($check_stmt);
                $result = mysqli_stmt_get_result($check_stmt);
                $booking = mysqli_fetch_assoc($result);
                
                $booking_datetime = strtotime($booking['booking_date'] . ' ' . $booking['end_time']);
                
                if ($booking['status'] == 'approved' && $booking_datetime > time()) {
                    throw new Exception("Cannot delete approved bookings that haven't elapsed");
                }
                
                $delete_sql = "DELETE FROM bookings WHERE booking_id = ?";
                break;
            case 'lab':
                // Check if lab has any active bookings
                $check_bookings = "SELECT COUNT(*) as count FROM bookings WHERE lab_id = ? AND booking_date >= CURDATE()";
                $stmt = mysqli_prepare($conn, $check_bookings);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $booking_count = mysqli_fetch_assoc($result)['count'];

                if ($booking_count > 0) {
                    throw new Exception("Cannot delete lab: There are active bookings for this lab");
                }

                // Delete lab
                $delete_sql = "DELETE FROM computer_labs WHERE lab_id = ?";
                break;

            case 'unit':
                // Check if unit has any active bookings
                $check_bookings = "SELECT COUNT(*) as count FROM bookings WHERE unit_id = ? AND booking_date >= CURDATE()";
                $stmt = mysqli_prepare($conn, $check_bookings);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $booking_count = mysqli_fetch_assoc($result)['count'];

                if ($booking_count > 0) {
                    throw new Exception("Cannot delete unit: There are active bookings for this unit");
                }

                // Delete unit
                $delete_sql = "DELETE FROM units WHERE unit_id = ?";
                break;

            case 'lecturer':
                // Check if lecturer has any active bookings
                $check_bookings = "SELECT COUNT(*) as count FROM bookings WHERE lecturer_id = ? AND booking_date >= CURDATE()";
                $stmt = mysqli_prepare($conn, $check_bookings);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $booking_count = mysqli_fetch_assoc($result)['count'];

                if ($booking_count > 0) {
                    throw new Exception("Cannot delete lecturer: There are active bookings for this lecturer");
                }

                // Delete lecturer
                $delete_sql = "DELETE FROM lecturers WHERE lecturer_id = ?";
                break;

            case 'student':
                // Delete units associated with the student
                $delete_units_sql = "DELETE FROM student_units WHERE student_id = ?";
                $stmt = mysqli_prepare($conn, $delete_units_sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception("Failed to delete units for the student");
                }

                // Delete student
                $delete_sql = "DELETE FROM students WHERE student_id = ?";
                break;

            default:
                throw new Exception("Invalid item type specified");
        }

        // Execute delete query
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Failed to delete " . $type);
        }

        // Commit transaction
        mysqli_commit($conn);
        $response['success'] = true;
        $response['message'] = ucfirst($type) . " deleted successfully";
    } catch (Exception $e) {
        // Rollback transaction on error
        mysqli_rollback($conn);
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;


