<?php
session_start();
require_once "config.php";
include "email_notifications.php";

// Check if student is logged in
if (!isset($_SESSION["student_loggedin"]) || $_SESSION["student_loggedin"] !== true) {
    header("location: student_login.php");
    exit;
}

$student_id = $_SESSION["student_id"];
$success_message = $error_message = '';

// Handle unit selection form submission
if (isset($_POST['update_units'])) {
    // Begin transaction
    mysqli_begin_transaction($conn);
    try {
        // Delete existing units for current semester
        $current_semester = date('Y') . (date('n') <= 6 ? '1' : '2'); // Determine current semester
        $delete_sql = "DELETE FROM student_units WHERE student_id = ? AND semester = ?";
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "is", $student_id, $current_semester);
        mysqli_stmt_execute($stmt);

        // Insert newly selected units
        if (isset($_POST['units']) && is_array($_POST['units'])) {
            $insert_sql = "INSERT INTO student_units (student_id, unit_id, semester, created_at) VALUES (?, ?, ?, NOW())";
            $stmt = mysqli_prepare($conn, $insert_sql);

            foreach ($_POST['units'] as $unit_id) {
                mysqli_stmt_bind_param($stmt, "iis", $student_id, $unit_id, $current_semester);
                mysqli_stmt_execute($stmt);
            }
        }

        mysqli_commit($conn);
        $success_message = "Units updated successfully!";
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error_message = "Error updating units. Please try again.";
    }
}

// Get all available units
$units_sql = "SELECT unit_id, unit_code, unit_name FROM units WHERE is_active = 1 ORDER BY unit_code";
$units_result = mysqli_query($conn, $units_sql);

// Get student's enrolled units
$enrolled_units_sql = "SELECT unit_id FROM student_units WHERE student_id = ? AND semester = ?";
$stmt = mysqli_prepare($conn, $enrolled_units_sql);
$current_semester = date('Y') . (date('n') <= 6 ? '1' : '2');
mysqli_stmt_bind_param($stmt, "is", $student_id, $current_semester);
mysqli_stmt_execute($stmt);
$enrolled_result = mysqli_stmt_get_result($stmt);

$enrolled_units = [];
while ($row = mysqli_fetch_assoc($enrolled_result)) {
    $enrolled_units[] = $row['unit_id'];
}

// Get bookings for enrolled units
if (count($enrolled_units) > 0) {
    $placeholders = str_repeat('?,', count($enrolled_units) - 1) . '?';
    $bookings_sql = "SELECT b.*, l.first_name, l.last_name, c.lab_name, u.unit_name, u.unit_code
                     FROM bookings b
                     JOIN lecturers l ON b.lecturer_id = l.lecturer_id
                     JOIN computer_labs c ON b.lab_id = c.lab_id
                     JOIN units u ON b.unit_id = u.unit_id
                     WHERE b.unit_id IN ($placeholders)
                     AND b.booking_date >= CURDATE()
                     ORDER BY b.booking_date ASC, b.start_time ASC";

    $stmt = mysqli_prepare($conn, $bookings_sql);
    $types = str_repeat('i', count($enrolled_units));
    mysqli_stmt_bind_param($stmt, $types, ...$enrolled_units);
    mysqli_stmt_execute($stmt);
    $bookings_result = mysqli_stmt_get_result($stmt);
} else {
    $bookings_result = null; // No bookings to fetch
}

// Update email preferences if form submitted
if (isset($_POST['update_preferences'])) {
    $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;

    $update_sql = "UPDATE students SET email_notifications = ? WHERE student_id = ?";
    $stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($stmt, "ii", $email_notifications, $student_id);
    mysqli_stmt_execute($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Zetech Lab Bookings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    body {
        padding-bottom: 10px;
    }

    @media (max-width: 768px) {
        body {
            padding-bottom: 100px;
        }
    }
</style>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand fw-bold">Zetech Lab Booking System</a>
            <div class="d-flex">
                <span class="navbar-text me-3">Welcome, <?php echo htmlspecialchars($_SESSION["student_name"]); ?></span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Unit Selection</h5>
                <p class="card-text">Select your units for the current semester (<?php echo $current_semester; ?>)</p>

                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <form method="POST" class="mt-3">
                    <div class="row">
                        <?php while ($unit = mysqli_fetch_assoc($units_result)): ?>
                            <div class="col-md-6 mb-2">
                                <div class="form-check">
                                    <input type="checkbox"
                                        class="form-check-input"
                                        name="units[]"
                                        value="<?php echo $unit['unit_id']; ?>"
                                        id="unit_<?php echo $unit['unit_id']; ?>"
                                        <?php echo in_array($unit['unit_id'], $enrolled_units) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="unit_<?php echo $unit['unit_id']; ?>">
                                        <?php echo htmlspecialchars($unit['unit_code'] . ' - ' . $unit['unit_name']); ?>
                                    </label>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <button type="submit" name="update_units" class="btn btn-primary mt-3">
                        Update Units
                    </button>
                </form>
            </div>
        </div>

        <!-- Email Preferences -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Email Notification Preferences</h5>
                <form method="POST" class="mt-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="email_notifications" id="email_notifications"
                            <?php echo $_SESSION['email_notifications'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="email_notifications">
                            Receive email notifications for computer lab classes
                        </label>
                    </div>
                    <button type="submit" name="update_preferences" class="btn btn-primary mt-2">
                        Update Preferences
                    </button>
                </form>
            </div>
        </div>

        <!-- Upcoming Classes -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Upcoming Lab Classes</h5>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Unit</th>
                                <th>Lecturer</th>
                                <th>Lab</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($bookings_result && mysqli_num_rows($bookings_result) > 0): ?>
                                <?php while ($booking = mysqli_fetch_assoc($bookings_result)): ?>
                                    <tr>
                                        <td><?php echo date('D, M j, Y', strtotime($booking['booking_date'])); ?></td>
                                        <td><?php echo date('h:i A', strtotime($booking['start_time'])) . ' - ' .
                                                date('h:i A', strtotime($booking['end_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($booking['unit_code'] . ' - ' . $booking['unit_name']); ?></td>
                                        <td><?php echo htmlspecialchars($booking['first_name'] . ' ' . $booking['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($booking['lab_name']); ?></td>
                                        <td>
                                            <span class="badge <?php
                                                                echo $booking['status'] == 'approved' ? 'bg-success' : ($booking['status'] == 'rejected' ? 'bg-danger' :
                                                                    'bg-warning'); ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No upcoming lab classes found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Registered Units Section -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Registered Units</h5>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Unit Code</th>
                                <th>Unit Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($enrolled_units) > 0): ?>
                                <?php
                                // Fetch details of enrolled units
                                $enrolled_units_placeholders = implode(',', array_fill(0, count($enrolled_units), '?'));
                                $enrolled_units_sql = "SELECT unit_code, unit_name FROM units WHERE unit_id IN ($enrolled_units_placeholders)";
                                $stmt = mysqli_prepare($conn, $enrolled_units_sql);
                                $types = str_repeat('i', count($enrolled_units));
                                mysqli_stmt_bind_param($stmt, $types, ...$enrolled_units);
                                mysqli_stmt_execute($stmt);
                                $enrolled_units_result = mysqli_stmt_get_result($stmt);

                                while ($unit = mysqli_fetch_assoc($enrolled_units_result)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($unit['unit_code']); ?></td>
                                        <td><?php echo htmlspecialchars($unit['unit_name']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="2" class="text-center">No registered units found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <footer class="text-center mt-4">
        <p class="text-muted">© <?php echo date("Y"); ?> Zetech Lab Booking. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>