<?php
session_start();
require_once "config.php";

// Check if already logged in
if (isset($_SESSION["student_loggedin"]) && $_SESSION["student_loggedin"] === true) {
    header("location: student_dashboard.php");
    exit;
}

$admission_number = $password = "";
$admission_number_err = $password_err = $login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["admission_number"]))) {
        $admission_number_err = "Please enter admission number.";
    } else {
        $admission_number = trim($_POST["admission_number"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    if (empty($admission_number_err) && empty($password_err)) {
        $sql = "SELECT student_id, admission_number, first_name, last_name, password, email_notifications 
                FROM students WHERE admission_number = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_admission);
            $param_admission = $admission_number;

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result(
                        $stmt,
                        $id,
                        $admission_number,
                        $first_name,
                        $last_name,
                        $hashed_password,
                        $email_notifications
                    );
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            session_start();

                            $_SESSION["student_loggedin"] = true;
                            $_SESSION["student_id"] = $id;
                            $_SESSION["student_admission"] = $admission_number;
                            $_SESSION["student_name"] = $first_name . " " . $last_name;
                            $_SESSION["email_notifications"] = $email_notifications;

                            header("location: student_dashboard.php");
                        } else {
                            $login_err = "Invalid admission number or password.";
                        }
                    }
                } else {
                    $login_err = "Invalid admission number or password.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login - Zetech Lab Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 1rem;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <!-- Logo -->
                    <img src="https://elearning.zetech.ac.ke/pluginfile.php/1/theme_edutor/logo/1727861548/Portrait%20Logo%20282C%20%281%29.png" alt="Zetech Logo" class="h-10 mr-3">
                    <div class="text-2xl font-bold text-blue-900">
                        Zetech Lab Booking
                    </div>
                </div>
                <div class="hidden md:block">
                    <div class="flex items-center space-x-4">
                        <a href="index.php" class="text-gray-700 hover:text-blue-900 px-3 py-2">Home</a>
                        <a href="#" class="text-gray-700 hover:text-blue-900 px-3 py-2" id="book-computer"></a>
                        <a href="#help" class="text-gray-700 hover:text-blue-900 px-3 py-2"></a>
                        <a href="student_login.php" class="bg-blue-900 text-white px-4 py-2 rounded-md">Student Login</a>
                        <a href="login.php" class="bg-blue-900 text-white px-4 py-2 rounded-md">Lecturer Login</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="card mx-auto" style="max-width: 400px;">
            <div class="card-body">
                <h2 class="text-center mb-4">Student Login</h2>
                <?php
                if (!empty($login_err)) {
                    echo '<div class="alert alert-danger">' . $login_err . '</div>';
                }
                ?>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="mb-3">
                        <label class="form-label">Admission Number</label>
                        <input type="text" name="admission_number" class="form-control <?php echo (!empty($admission_number_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $admission_number; ?>" required>
                        <div class="invalid-feedback"><?php echo $admission_number_err; ?></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" required>
                        <div class="invalid-feedback"><?php echo $password_err; ?></div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="rememberMe">
                        <label class="form-check-label" for="rememberMe">Remember Me</label>
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </div>
                </form>
                <div class="text-center">
                    <a href="#" class="text-muted">Forgot Password?</a>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4">
        <p class="text-muted">© <?php echo date("Y"); ?> Zetech Lab Booking. All rights reserved.</p>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>