<?php
include 'config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function sendBookingStatusEmail($booking, $status)
{
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;        
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        // Recipients
        $mail->setFrom('no-reply@zetech.ac.ke', 'Zetech Lab Booking System');
        $mail->addAddress($booking['lecturer_email']);

        // Content
        $mail->isHTML(true);

        // Prepare email content based on status
        switch ($status) {
            case 'approved':
                $subject = 'Lab Booking Approved';
                $message = "Dear {$booking['first_name']} {$booking['last_name']},<br><br>";
                $message .= "Your lab booking request has been approved. Here are the details:<br><br>";
                $message .= "Lab: {$booking['lab_name']}<br>";
                $message .= "Unit: {$booking['unit_name']}<br>";
                $message .= "Date: {$booking['booking_date']}<br>";
                $message .= "Time: {$booking['start_time']} - {$booking['end_time']}<br><br>";
                $message .= "Please ensure you arrive on time and follow all lab rules and regulations.<br><br>";
                $message .= "Best regards,<br>Zetech Lab Management";
                break;

            case 'rejected':
                $subject = 'Lab Booking Rejected';
                $message = "Dear {$booking['first_name']} {$booking['last_name']},<br><br>";
                $message .= "Unfortunately, your lab booking request has been rejected. Here are the details:<br><br>";
                $message .= "Lab: {$booking['lab_name']}<br>";
                $message .= "Unit: {$booking['unit_name']}<br>";
                $message .= "Date: {$booking['booking_date']}<br>";
                $message .= "Time: {$booking['start_time']} - {$booking['end_time']}<br><br>";
                $message .= "Please contact the lab administrator for more information or submit a new booking request.<br><br>";
                $message .= "Best regards,<br>Zetech Lab Management";
                break;

            case 'cancelled':
                $subject = 'Lab Booking Cancelled';
                $message = "Dear {$booking['first_name']} {$booking['last_name']},<br><br>";
                $message .= "Your lab booking has been cancelled as requested. Here are the details:<br><br>";
                $message .= "Lab: {$booking['lab_name']}<br>";
                $message .= "Unit: {$booking['unit_name']}<br>";
                $message .= "Date: {$booking['booking_date']}<br>";
                $message .= "Time: {$booking['start_time']} - {$booking['end_time']}<br><br>";
                $message .= "You can submit a new booking request at any time.<br><br>";
                $message .= "Best regards,<br>Zetech Lab Management";
                break;
        }

        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->AltBody = strip_tags($message);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

function sendStudentNotificationEmail($booking, $status) {
    // Get students enrolled in the unit
    global $conn;
    $students_sql = "SELECT s.email, s.first_name, s.last_name 
                     FROM students s
                     JOIN student_units su ON s.student_id = su.student_id
                     WHERE su.unit_id = ? AND s.email_notifications = 1";
    
    $stmt = mysqli_prepare($conn, $students_sql);
    mysqli_stmt_bind_param($stmt, "i", $booking['unit_id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    while($student = mysqli_fetch_assoc($result)) {
        $to = $student['email'];
        $subject = "Lab Booking Status Update - " . $booking['unit_code'];
        
        $message = "Dear " . $student['first_name'] . " " . $student['last_name'] . ",\n\n";
        $message .= "This is to inform you that the lab booking for " . $booking['unit_code'] . " - " . 
                   $booking['unit_name'] . " has been " . $status . ".\n\n";
        $message .= "Details:\n";
        $message .= "Date: " . date('D, M j, Y', strtotime($booking['booking_date'])) . "\n";
        $message .= "Time: " . date('h:i A', strtotime($booking['start_time'])) . " - " . 
                   date('h:i A', strtotime($booking['end_time'])) . "\n";
        $message .= "Lab: " . $booking['lab_name'] . "\n";
        $message .= "Lecturer: " . $booking['first_name'] . " " . $booking['last_name'] . "\n\n";
        $message .= "You can view all your upcoming lab classes on the student dashboard.\n\n";
        $message .= "Best regards,\nZetech Lab Booking System";
        
        $headers = "From: noreply@zetech.edu";
        
        mail($to, $subject, $message, $headers);
    }
}

// Function to send reminder emails for upcoming bookings
function sendReminderEmails()
{
    global $conn;

    // Get bookings for tomorrow
    $tomorrow = date('Y-m-d', strtotime('+1 day'));
    $sql = "SELECT b.*, l.email as lecturer_email, l.first_name, l.last_name,
            c.lab_name, u.unit_name 
            FROM bookings b
            JOIN lecturers l ON b.lecturer_id = l.lecturer_id
            JOIN computer_labs c ON b.lab_id = c.lab_id
            JOIN units u ON b.unit_id = u.unit_id
            WHERE b.booking_date = ? AND b.status = 'approved'";

    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $tomorrow);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        while ($booking = mysqli_fetch_assoc($result)) {
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USERNAME;
                $mail->Password   = SMTP_PASSWORD;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;

                // Recipients
                $mail->setFrom('no-reply@zetech.ac.ke', 'Zetech Lab Booking System');
                $mail->addAddress($booking['lecturer_email']);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Reminder: Lab Booking Tomorrow';

                $message = "Dear {$booking['first_name']} {$booking['last_name']},<br><br>";
                $message .= "This is a reminder about your lab booking tomorrow. Here are the details:<br><br>";
                $message .= "Lab: {$booking['lab_name']}<br>";
                $message .= "Unit: {$booking['unit_name']}<br>";
                $message .= "Time: {$booking['start_time']} - {$booking['end_time']}<br><br>";
                $message .= "Please ensure you arrive on time and follow all lab rules and regulations.<br><br>";
                $message .= "Best regards,<br>Zetech Lab Management";

                $mail->Body    = $message;
                $mail->AltBody = strip_tags($message);

                $mail->send();
            } catch (Exception $e) {
                error_log("Reminder email sending failed: {$mail->ErrorInfo}");
            }
        }
    }
}
